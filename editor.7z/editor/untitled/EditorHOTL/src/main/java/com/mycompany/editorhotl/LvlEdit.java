package com.mycompany.editorhotl;

import javax.swing.*;

public class LvlEdit {
    private JPanel panel1;
    private JButton saveButton;
    private JButton button2;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTextField textField6;
    private JTextField textField7;
    private JButton prevButton;
    private JButton nextButton;
    private JTable table1;
}
