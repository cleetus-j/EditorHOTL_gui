package com.mycompany.editorhotl;

import java.awt.Color;

public class PAL {
    //These are all the colors, that the game uses.
    Color[] colors={new Color(0,0,0),new Color(85,85,85),new Color(170,170,170),new Color(255,255,255),new Color(0,0,0),
    new Color(0,0,0),new Color(85,85,85),new Color(170,170,170),new Color(255,255,255),new Color(255,255,255),new Color(255,255,255),
    new Color(85,85,85),new Color(0,0,0),new Color(85,85,85),new Color(0,0,0),new Color(255,255,255),   //This is the first palette.

            new Color(0,0,0),new Color(85,85,85),new Color(170,170,170),new Color(255,255,255),new Color(0,0,0),
    new Color(85,0,0),new Color(170,85,0),new Color(255,170,85),new Color(255,255,170),new Color(255,255,0),new Color(255,255,170),
    new Color(255,85,0),new Color(170,0,0),new Color(85,170,0),new Color(0,0,170),new Color(0,85,255)};//Second palette, that the tiles are using.



}
