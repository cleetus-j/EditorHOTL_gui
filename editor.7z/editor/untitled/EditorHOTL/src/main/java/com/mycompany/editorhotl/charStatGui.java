package com.mycompany.editorhotl;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class charStatGui {
  
  public static void main() {
    SwingUtilities.invokeLater(charStatGui::createAndShowMainWindow);
  }
  
  private static void createAndShowMainWindow() {
    // Main Window Setup
    JFrame mainFrame = new JFrame("Character Stats Editor");
    mainFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    mainFrame.setSize(400, 200);
    mainFrame.setLayout(new FlowLayout());
    
    // Button to open the table window
    JButton characterStats = new JButton("Character Stats");
    JButton charNameEditor=new JButton("Character name editor");
    JButton charInventory=new JButton("Character Inventory");
    characterStats.addActionListener(_ -> charStatEdit());
    
    mainFrame.add(characterStats);
    mainFrame.add(charNameEditor);
    mainFrame.add(charInventory);
    mainFrame.setVisible(true);
  }
  
  private static void charStatEdit() {
    // Table Window Setup
    JFrame tableFrame = new JFrame("CharStat");
    tableFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    tableFrame.setSize(1200, 400);
    byte[] data =getPlayerStats();
    int columns=2;
    String[] RowNames={"Starting Items","Inv. Full?","Min\\Max HP","Phys. DMG MIN-MAX","Magic DMG" +
            " MIN-MAX","Str, Int","Wisdom, Constitution","DEX, CHR"};
    DefaultTableModel model=new DefaultTableModel();
    model.addColumn("Col1");
    model.addColumn("Col2");
    model.addColumn("Name");
    for (int i = 0; i < data.length; i += columns) {
      Object[] row = new Object[columns];
      for (int j = 0; j < columns && (i + j) < data.length; j++) {
        row[j] = String.format("0x%02X", data[i + j]);
      }
      model.addRow(row);}
    for (int i = 0; i < RowNames.length; i++) {
      model.setValueAt(RowNames[i], i, model.getColumnCount() - 1);
    }
    // Create the JTable with editable cells
    JTable table = new JTable(model) {
      @Override
      public boolean isCellEditable(int row, int column) {
        return true; // All cells editable
      }
    };
    
    // Enable scrolling
    JScrollPane scrollPane = new JScrollPane(table);
    
    // Buttons for saving and printing data
    JButton saveButton = new JButton("Save to File");
    saveButton.addActionListener(_ -> saveTableData(table));
    
    JButton printButton = new JButton("Print Data");
    printButton.addActionListener(_ -> printTableData(table));
    
    // Panel to hold buttons
    JPanel buttonPanel = new JPanel();
    buttonPanel.add(saveButton);
    buttonPanel.add(printButton);
    ButtonGroup group=new ButtonGroup();
    String[] buttonLabels = {
            "CHR0", "CHR1", "CHR2", "CHR3",
            "CHR4", "CHR5", "CHR6", "CHR7"
    };
    int charNr=0;
    // Main panel layout
    JPanel mainPanel = new JPanel(new BorderLayout());
    mainPanel.add(scrollPane, BorderLayout.CENTER);
    mainPanel.add(buttonPanel, BorderLayout.SOUTH);
    // Create and add radio buttons to the panel and group
    for (String label : buttonLabels) {
      JRadioButton radioButton = new JRadioButton(label);
      radioButton.addActionListener(e-> {
        
      });
      group.add(radioButton);
      buttonPanel.add(radioButton);
    }
    tableFrame.add(mainPanel);
    tableFrame.setVisible(true);
  }
  
  // Save table data to a file
  public static byte[] getPlayerStats(){
    byte[]tempRes=new byte[16];
    System.arraycopy(GUI.currentROM.gameRom,(GUI.currentROM.playerStatPointer+16),tempRes,0,16);
    
    //new
    // byte[8*33];  //One player
    // character is 33
    // bytes for items and things
    // like that.
    
    return  tempRes;
  }
  private static void saveTableData(JTable table) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("saved_data.txt"))) {
      // Write column headers
      for (int col = 0; col < table.getColumnCount(); col++) {
        writer.write(table.getColumnName(col) + "\t");
      }
      writer.newLine();
      
      // Write row data
      for (int row = 0; row < table.getRowCount(); row++) {
        for (int col = 0; col < table.getColumnCount(); col++) {
          writer.write(table.getValueAt(row, col).toString() + "\t");
        }
        writer.newLine();
      }
      
      JOptionPane.showMessageDialog(null, "Data saved to saved_data.txt!");
    } catch (IOException e) {
      JOptionPane.showMessageDialog(null, "Error saving file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
  }
  
  // Print table data to console (for debugging)
  private static void printTableData(JTable table) {
    System.out.println("\nCurrent Table Data:");
    for (int row = 0; row < table.getRowCount(); row++) {
      for (int col = 0; col < table.getColumnCount(); col++) {
        System.out.print(table.getValueAt(row, col) + " | ");
      }
      System.out.println();
    }
  }
}